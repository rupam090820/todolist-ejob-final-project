import { Component,OnInit } from '@angular/core';
import { TodoApiService } from './todo-api.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit  {
public AllTodos:any=[];
public page:number=0;
public totalTodos:number=0;
public serachTodo:any='';
constructor(private apiService:TodoApiService) {}
ngOnInit(): void {
  this.populateTodos();
}
populateTodos(){
  this.apiService.getAllTods().subscribe((res:any)=>{
   //  console.log(res);
     console.table(res);
     this.AllTodos=res;
     this.totalTodos=res.length;
   });
}
}
