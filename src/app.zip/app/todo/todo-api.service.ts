import { Injectable } from '@angular/core';
// Import HttpClient class :
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class TodoApiService {

  constructor(private http:HttpClient) { }
  getAllTods(){
    return this.http.get('https://todolist-api.glitch.me/api/todos');
  }
}
