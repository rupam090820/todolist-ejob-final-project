export class Todo{
       constructor(
              public title:string,
              public desc:string,
              public created:string
       ){}
}